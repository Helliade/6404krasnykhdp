"""
Пакет тестов для ImageProcessing.
"""